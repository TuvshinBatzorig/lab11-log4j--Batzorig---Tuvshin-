# Analysis.md

## Commands

grep "ERROR" logs/app.log  
tail -f logs/app.log  
tail -f logs/app.log | grep "WARN"  
awk '{print $3}' logs/app.log | sort | uniq -c  

## Answer 4.1

tail -f нь real-time лог харуулдаг тул debug хийхэд илүү ашигтай.
