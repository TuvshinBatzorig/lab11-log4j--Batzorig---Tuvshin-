public class Main {
    public static void main(String[] args) {

        BankAccount acc = new BankAccount(1000);

        acc.deposit(500);
        acc.deposit(-50);

        acc.withdraw(200);
        acc.withdraw(2000);

        acc.getBalance();
    }
}
