import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BankAccount {

    private static final Logger logger = LogManager.getLogger(BankAccount.class);
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public void deposit(double amount) {
        logger.trace("Entering deposit() with amount={}", amount);

        if (amount < 0) {
            logger.warn("Invalid deposit amount: {}", amount);
            return;
        }

        logger.debug("Before deposit balance={}", balance);
        balance += amount;
        logger.info("Deposited {}. New balance={}", amount, balance);
        logger.trace("Exiting deposit()");
    }

    public void withdraw(double amount) {
        logger.trace("Entering withdraw() with amount={}", amount);

        if (amount < 0) {
            logger.warn("Invalid withdraw amount: {}", amount);
            return;
        }

        logger.debug("Before withdraw balance={}", balance);

        if (amount > balance) {
            logger.error("Not enough balance. amount={}, balance={}", amount, balance);
            return;
        }

        balance -= amount;
        logger.info("Withdrawn {}. New balance={}", amount, balance);
        logger.trace("Exiting withdraw()");
    }

    public double getBalance() {
        logger.debug("Current balance={}", balance);
        return balance;
    }
}
